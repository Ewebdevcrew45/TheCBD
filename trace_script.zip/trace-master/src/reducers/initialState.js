// TODO: clean this up
export default {
  products: [],
  name: "",
  description: "",
  latitude: "",
  longitude: "",
  passageInstance: null,
  accounts: null,
  web3Accounts: null,
  productIdToView: "",
  alert: {
    visible: false,
    content: "",
    color: "",
    rawData: ""
  }
};